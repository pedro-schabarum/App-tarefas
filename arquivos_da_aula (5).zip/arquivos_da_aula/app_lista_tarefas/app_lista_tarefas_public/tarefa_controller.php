<?php

	require_once '../../app_lista_tarefas/tarefa_controller.php';

?>